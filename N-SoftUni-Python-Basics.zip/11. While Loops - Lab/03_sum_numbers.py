original = int(input())
sum_nums = 0

while sum_nums < original:
    new_num = int(input())
    sum_nums += new_num


print(sum_nums)
