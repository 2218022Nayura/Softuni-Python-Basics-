my_bool = True

while my_bool == True:
    my_name = input()
    if my_name == "Stop":
        my_bool = False
    else:
        print(my_name)
