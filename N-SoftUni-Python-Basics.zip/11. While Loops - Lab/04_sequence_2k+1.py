my_num = int(input())
initial = 1

while initial <= my_num:
    print(initial)
    initial = 2 * initial + 1
