number = int(input())

if -100 <= number <= 100 and number != 0:
    print("Yes")
else:
    print("No")
