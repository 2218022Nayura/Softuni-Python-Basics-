product = input()
product1 = ["banana", "apple", "kiwi", "cherry", "lemon", "grapes"]
product2 = ["tomato", "cucumber", "pepper", "carrot"]
if product in product1:
    print("fruit")
elif product in product2:
    print("vegetable")
else:
    print("unknown")
