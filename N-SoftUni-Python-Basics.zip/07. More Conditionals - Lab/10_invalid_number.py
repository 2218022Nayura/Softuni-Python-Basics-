my_num = int(input())

if my_num in range(100, 200 + 1) or my_num == 0:
    pass
else:
    print("invalid")
