day = input()
if day == "Monday" or day == "Tuesday" or day == "Friday":
    print("12")
elif day == "Wednesday" or day == "Thursday":
    print("14")
elif day == "Sunday" or day == "Saturday":
    print("16")
