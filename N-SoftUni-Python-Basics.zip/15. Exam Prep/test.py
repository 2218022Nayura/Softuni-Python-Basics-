team = input()

if not "Argentina":
    print("Not")
elif not "Brazil":
    print("Not")
else:
    print("Hello")
