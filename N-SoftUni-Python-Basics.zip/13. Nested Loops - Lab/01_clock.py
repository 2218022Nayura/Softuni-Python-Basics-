for x in range(24):
    for i in range(60):
        print(f"{x}:{i}")
