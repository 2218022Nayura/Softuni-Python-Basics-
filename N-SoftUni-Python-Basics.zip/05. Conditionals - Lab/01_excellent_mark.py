grade = float(input())
if grade >= 5.50:
    print("Excellent!")
