number = int(input())

if number % 2 == 0:
    print("even")
else:
    print("odd")
