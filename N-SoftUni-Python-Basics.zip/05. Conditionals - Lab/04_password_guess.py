password = input()

secret_phrase = "s3cr3t!P@ssw0rd"

if password == secret_phrase:
    print("Welcome")
else:
    print("Wrong password!")
