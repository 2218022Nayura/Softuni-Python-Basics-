first_number = int(input())
second_number = int(input())

if first_number > second_number:
    print(first_number)
else:
    print(second_number)
