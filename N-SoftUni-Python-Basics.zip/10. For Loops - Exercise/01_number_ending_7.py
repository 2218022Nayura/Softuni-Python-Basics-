for x in range(1, 1000 + 1):
    if x % 10 == 7:
        print(x)
