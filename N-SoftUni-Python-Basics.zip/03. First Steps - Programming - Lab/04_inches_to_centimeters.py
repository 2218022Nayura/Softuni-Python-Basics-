my_inches = float(input())
my_centimeters = 2.54 * my_inches
print(my_centimeters)
