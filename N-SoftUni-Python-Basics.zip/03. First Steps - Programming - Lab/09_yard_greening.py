yard_area = float(input())
price = 7.61
discount = float(yard_area * price * 0.18)
final_price = float(yard_area * price * 0.82)
print(f"The final price is: {final_price} lv.")
print(f"The discount is: {discount} lv.")
