architect_name = input()
project_number = int(input())
needed_hours = project_number * 3
print(
    f"The architect {architect_name} will need {needed_hours} hours to complete {project_number} project/s."
)
