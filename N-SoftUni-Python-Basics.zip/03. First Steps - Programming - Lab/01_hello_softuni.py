print("Hello SoftUni")
text = "Hello"
print(text)
text = 6
print(text)
