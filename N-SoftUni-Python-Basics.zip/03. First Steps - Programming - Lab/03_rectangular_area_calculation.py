side_a = int(input())
side_b = int(input())
area = side_a * side_b

# this symbol is used to leave comments in code
print(area)
