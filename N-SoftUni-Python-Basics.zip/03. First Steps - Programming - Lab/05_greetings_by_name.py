name = input()
print("Hello, " + name + "!")

name = input()
print(f"Hello, {name}!")

name = input()
print("Hello, ", end="")
print(name)

some_text = "hello"
print(some_text, end="")

print("Hello, ", end="I`m on the same row!!!")
