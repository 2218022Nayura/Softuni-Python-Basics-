dog_food_price = 2.5
cat_food_price = 4

dog_packs = int(input())
cat_packs = int(input())
total_cost = dog_packs * dog_food_price + cat_packs * cat_food_price

print(f"{total_cost} lv.")
