num = int(input())

for x in range(num, 0, -1):
    print(x)
