for x in range(1, 100 + 1):
    print(x)
