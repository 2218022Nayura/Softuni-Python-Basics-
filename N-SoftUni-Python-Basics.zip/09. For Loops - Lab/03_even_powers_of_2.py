num = int(input())

for x in range(num + 1):
    if x % 2 == 0:
        print(2**x)
    else:
        pass
