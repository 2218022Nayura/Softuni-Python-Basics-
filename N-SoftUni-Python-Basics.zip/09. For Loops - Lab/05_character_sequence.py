my_string = input()

for x in my_string:
    print(x)
