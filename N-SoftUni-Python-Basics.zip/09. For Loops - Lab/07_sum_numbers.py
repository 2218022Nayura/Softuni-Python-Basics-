my_num = int(input())
my_sum = 0
new_num = 0

for x in range(my_num):
    new_num = int(input())
    my_sum += new_num


print(my_sum)
