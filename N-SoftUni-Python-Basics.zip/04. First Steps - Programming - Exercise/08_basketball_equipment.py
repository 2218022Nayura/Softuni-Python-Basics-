yearly_tax = int(input())
shoes_price = yearly_tax * 0.60
track_suit_price = shoes_price * 0.80
ball_price = track_suit_price / 4
accessories = ball_price / 5
total_tum = yearly_tax + shoes_price + track_suit_price + ball_price + accessories
print(total_tum)
