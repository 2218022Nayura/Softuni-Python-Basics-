usd = float(input())
bgn = usd * 1.79549
print(bgn)
print(f"{bgn:.2f}")
