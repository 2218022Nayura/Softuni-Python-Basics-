from math import pi

angle_radians = float(input())
angle_degree = angle_radians * 180 / pi
print(angle_degree)
